export const firebaseConfig = {
  apiKey: "AIzaSyBS-hhNbqf9p7WGaDUgEaUj99fg1TZM9VI",
  authDomain: "angularapp5-b957c.firebaseapp.com",
  projectId: "angularapp5-b957c",
  storageBucket: "angularapp5-b957c.appspot.com",
  messagingSenderId: "933491611132",
  appId: "1:933491611132:web:37d67106c3a34a72cf8e79"
};