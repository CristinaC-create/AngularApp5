// src/environments/firebase-data.service.ts
import { Injectable } from '@angular/core';
import { getDatabase, ref, set, get, child } from '@angular/fire/database';

@Injectable({ providedIn: 'root' })
export class FirebaseDataService {
  private db = getDatabase();

  // Save the entire cart array to the 'cart' key in the DB
  saveCartData(cart: any[]): Promise<void> {
    return set(ref(this.db, 'cart'), cart);
  }

  // Fetch the cart from the 'cart' key in the DB
  getCartData(): Promise<any> {
    const dbRef = ref(this.db);
    return get(child(dbRef, 'cart'));
  }
}