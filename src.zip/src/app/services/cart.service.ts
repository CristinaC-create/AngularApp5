import { Injectable } from '@angular/core';
import { FirebaseDataService } from './firebase-data.service'; 
@Injectable({ providedIn: 'root' })
export class CartService {
  private items: any[] = [];

  constructor(private firebaseService: FirebaseDataService) { }

  addToCart(item: any) {
    this.items.push(item);
  }

  getItems() {
    return this.items;
  }

  removeItem(index: number) {
    this.items.splice(index, 1);
  }

  clearCart() {
    this.items = [];
  }

  // ✅ Save cart to Firebase Realtime Database
  saveCart() {
    return this.firebaseService.saveCartData(this.items).then(() => {
      console.log('Cart saved to Firebase!');
    }).catch((error) => {
      console.error('Error saving cart:', error);
    });
  }

  // ✅ Load cart from Firebase Realtime Database
  loadCart() {
    return this.firebaseService.getCartData().then(snapshot => {
      if (snapshot.exists()) {
        this.items = snapshot.val(); // set local items to loaded data
        console.log('Cart loaded from Firebase:', this.items);
      } else {
        console.log('No cart data found in Firebase.');
      }
    }).catch((error) => {
      console.error('Error loading cart:', error);
    });
  }
}