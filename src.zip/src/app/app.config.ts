
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { HomeComponent } from './pages/home/home.component';
import { RecipeViewComponent } from './pages/recipe-view/recipe-view.component';
import { IngredientsViewComponent } from './pages/ingredients-view/ingredients-view.component';
import { CartViewComponent } from './pages/cart-view/cart-view.component';
import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { firebaseConfig } from './services/firebase.config';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    importProvidersFrom(HomeComponent, RecipeViewComponent, IngredientsViewComponent, CartViewComponent)
  ]
};