import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-cart-view',
  standalone: true,
  imports: [CommonModule],
  styleUrls: ['./cart-view.component.css'],
  templateUrl: './cart-view.component.html',
})
export class CartViewComponent {
  items: any[] = [];

  constructor(private cartService: CartService) { }

  ngOnInit() {
    this.cartService.loadCart().then(() => {
      this.items = this.cartService.getItems(); // load from Firebase into local view
    });
  }

  removeItem(index: number) {
    this.cartService.removeItem(index);
    this.items = this.cartService.getItems();
  }

  clearCart() {
    this.cartService.clearCart();
    this.items = [];
  }

  saveCartToFirebase() {
    this.cartService.saveCart();
  }

  loadCartFromFirebase() {
    this.cartService.loadCart().then(() => {
      this.items = this.cartService.getItems();
    });
  }
}